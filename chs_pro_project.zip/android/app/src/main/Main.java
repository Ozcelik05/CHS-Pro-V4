public class Main { }

public class SimpleApp {
    public static void main(String[] args) {
        System.out.println("CHS Pro V4");
    }
}
